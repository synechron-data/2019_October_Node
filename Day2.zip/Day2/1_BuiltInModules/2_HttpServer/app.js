// const http = require('http');

// const server = http.createServer((req, res) => {
//     // console.log(req.url);
//     // console.log(req.headers);
//     res.setHeader("content-type", "text/html");
//     res.write("<h1>Response from Node Http Server..</h1>");
//     res.end();
// });

// server.listen(3000, () => {
//     console.log("Server Started....");
// });

// -------------------------------------------------
const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    fs.readFile('./index.html', (err, htmlContent) => {
        if (err)
            res.end("HTML page not found...");

        res.setHeader("content-type", "text/html");
        res.write(htmlContent);
        res.end();
    });
});

server.listen(3000, () => {
    console.log("Server Started....");
});