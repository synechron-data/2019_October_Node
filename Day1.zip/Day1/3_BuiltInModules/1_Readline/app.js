const readline = require('readline');

var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter a number One: ", (n1) => {
    let num1 = parseInt(n1);
    rl.question("Enter a number Two: ", (n2) => {
        let num2 = parseInt(n2);
        let sum = num1 + num2;
        console.log("Result is: %s", sum);
        rl.close();
    });
});

// rl.question("Enter a number: ", (n1) => {
//     console.log("You entered %s", n1);
//     rl.close();
// });

// console.log("--------- Last Line ---------");

// var count = 0;
// setInterval(function () {
//     console.log(++count);
// }, 1000);