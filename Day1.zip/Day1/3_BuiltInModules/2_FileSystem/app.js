const fs = require('fs');

// // ----------------------------------- Write File

// fs.writeFile('./file1.txt', "Hello from Node App", "utf-8", (err) => {
//     if (err)
//         console.log(err);
//     else
//         console.log("File Write Completed....");
// });

// console.log("Completed....");

// // ----------------------------------- Append File

// fs.appendFile('./file2.txt', "Hello from Node App\n", "utf-8", (err) => {
//     if (err)
//         console.log(err);
//     else
//         console.log("File Append Completed....");
// });

// console.log("Completed....");

// ----------------------------------- Read File

fs.readFile('./file3.txt', "utf-8", (err, data) => {
    if (err)
        console.log(err);
    else
        console.log(data);
});

console.log("Completed....");