const StringEmitter = require('./StringEmitter');

let sEmitter = new StringEmitter();

// setInterval(function () {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);

// sEmitter.pushString(function(s){
//     console.log(s);
// });

sEmitter.on('data', function (s) {
    console.log("S1 - ", s);
});

var count = 0;
function S2(s) {
    ++count;
    console.log("S2 - ", s.toUpperCase());
    if (count > 2) {
        sEmitter.removeListener('data', S2);
    }
}

sEmitter.on('data', S2);