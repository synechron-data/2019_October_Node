class Logger {
    log(message) {
        console.log(`${message} logged using Logger class method`);
    }
}

module.exports = Logger;