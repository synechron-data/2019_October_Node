const Logger = require('./Logger');

let instance = null;

function getInstance(){
    instance = new Logger();
    return instance;
}

module.exports.Logger = getInstance();

// function getLogger() {
//     if (!instance)
//         instance = new Logger();
//     return instance;
// }

// module.exports.getLogger = getLogger;

