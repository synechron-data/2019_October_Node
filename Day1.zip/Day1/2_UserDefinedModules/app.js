// console.log(module);

// const msg = require('./message.js');
// console.log(msg);
// console.log(msg.firstname);
// console.log(msg.lastname);
// msg.log("Hi from App");

// var e1 = new msg.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const msg1 = require('./message.js');
// const msg2 = require('./message.js');

// const msg = require('./message');
// console.log(msg);

// const logger = require('./logger');
// console.log(logger);

// const logger1 = require('./logger1');
// console.log(logger1);

// ------------------------------------------
// const loggerFactory = require('./loggerFactory');

// let dbLogger = loggerFactory.DBLFactory.getLogger();
// let flLogger = loggerFactory.FLFactory.getLogger();

// dbLogger.log("Hello");
// flLogger.log("Hello");

// -------------------------------------------
const loggerSingle = require('./loggerSingle');

// let logger1 = loggerSingle.Logger;
// let logger2 = loggerSingle.Logger;

let logger1 = loggerSingle.getLogger();
let logger2 = loggerSingle.getLogger();

console.log(logger1 === logger2);